import os
import queue as q
import threading
from typing import Callable, Dict, List
from datetime import datetime

from utils import fs
from utils.http import download_to_file
from plugins.generic_html import GenericHtmlPlugin


def pick_plugin(url: str):
    # For MVP we always fallback to generic plugin; extend here to route by domain
    return GenericHtmlPlugin()


class DownloadQueue:
    def __init__(self, download_dir: str = "downloads", concurrency: int = 3, on_log: Callable[[str], None] | None = None, on_status: Callable[[Dict, str], None] | None = None):
        self.download_dir = download_dir
        self.concurrency = max(1, concurrency)
        self.on_log = on_log
        self.on_status = on_status
        self._queue: q.Queue[Dict] = q.Queue()
        self._stop_event = threading.Event()
        self._workers: List[threading.Thread] = []
        fs.mkdir_p(download_dir)

    def add(self, item: Dict):
        entry = {"url": item["url"], "retries": 0, "status": "queued"}
        self._queue.put(entry)
        self._status(entry, "queued")
        self._log(f"[Add] {item['url']}")

    def start(self):
        if self._workers:
            return
        self._stop_event.clear()
        self._log("[Start] Downloading...")
        for _ in range(self.concurrency):
            t = threading.Thread(target=self._worker, daemon=True)
            self._workers.append(t)
            t.start()

        # Wait until queue is empty
        self._queue.join()
        self.stop()

    def stop(self):
        self._stop_event.set()
        self._log("[Stop] Stopping workers...")
        self._workers.clear()

    def _log(self, msg: str):
        if self.on_log:
            ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            self.on_log(f"[{ts}] {msg}")

    def _status(self, item: Dict, status: str):
        item["status"] = status
        if self.on_status:
            self.on_status(item, status)

    def _worker(self):
        while not self._stop_event.is_set():
            try:
                item = self._queue.get(timeout=0.2)
            except q.Empty:
                continue
            try:
                self._process_item(item)
            finally:
                self._queue.task_done()

    def _process_item(self, item: Dict):
        url = item["url"]
        self._status(item, "downloading")
        self._log(f"[Fetch] {url}")
        plugin = pick_plugin(url)
        try:
            job = plugin.fetch_images(url)
            title = plugin.sanitize_title(job.get("title") or "untitled")
            out_dir = fs.join(self.download_dir, fs.sanitize(title))
            fs.mkdir_p(out_dir)
            images = job.get("images", [])
            jpg_images = []
            for u in images:
                lu = u.lower()
                if ".jpg" in lu or ".jpeg" in lu:
                    jpg_images.append(u)
            self._log(f"[Images] {len(images)} found ({len(jpg_images)} jpg)")
            for idx, img_url in enumerate(jpg_images, start=1):
                ext = fs.guess_ext(img_url)
                filename = f"{idx:04d}.jpg"
                dest = fs.join(out_dir, filename)
                self._log(f"  [Get] {img_url}")
                ok, reason = download_to_file(img_url, dest)
                if not ok:
                    self._log(f"  [Fail] {img_url} ({reason})")
                try:
                    size = os.path.getsize(dest)
                except Exception:
                    size = 0
                self._log(f"  [Saved] {filename} ({size} bytes)")
            self._log(f"[Done] {title}")
            self._status(item, "done")
        except Exception as e:
            self._log(f"[Error] {url} -> {e}")
            self._status(item, "failed")


