import threading
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

from downloader import DownloadQueue


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Python Manga/Doujin Downloader")
        self.geometry("800x500")

        self._build_ui()
        self.queue = DownloadQueue(
            download_dir="downloads",
            concurrency=3,
            on_log=self._append_log,
            on_status=self._on_status,
        )

    def _build_ui(self):
        controls = ttk.Frame(self, padding=8)
        controls.pack(fill=tk.X)

        # Multiline input for multiple URLs
        self.url_text = tk.Text(controls, height=4)
        self.url_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        btns = ttk.Frame(controls)
        btns.pack(side=tk.LEFT, padx=(8, 0))
        ttk.Button(btns, text="Add", command=self._on_add).pack(fill=tk.X)
        ttk.Button(btns, text="Start", command=self._on_start).pack(fill=tk.X, pady=4)
        ttk.Button(btns, text="Stop", command=self._on_stop).pack(fill=tk.X)
        ttk.Button(btns, text="Load Links (.txt)", command=self._on_load_links).pack(fill=tk.X, pady=(4,0))

        body = ttk.Frame(self, padding=8)
        body.pack(fill=tk.BOTH, expand=True)

        left = ttk.Frame(body)
        left.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        ttk.Label(left, text="Queue").pack(anchor=tk.W)
        self.queue_list = tk.Listbox(left)
        self.queue_list.pack(fill=tk.BOTH, expand=True)

        right = ttk.Frame(body)
        right.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(8,0))
        ttk.Label(right, text="Logs").pack(anchor=tk.W)
        self.log_text = tk.Text(right, state=tk.DISABLED, wrap=tk.WORD)
        self.log_text.pack(fill=tk.BOTH, expand=True)

    def _append_log(self, msg: str):
        def _append():
            self.log_text.configure(state=tk.NORMAL)
            self.log_text.insert(tk.END, msg + "\n")
            self.log_text.see(tk.END)
            self.log_text.configure(state=tk.DISABLED)
        self.after(0, _append)

    def _on_add(self):
        raw = self.url_text.get("1.0", tk.END)
        items = []
        for chunk in raw.replace("\r", "").split("\n"):
            for url in [u.strip() for u in chunk.split(",") if u.strip()]:
                if url:
                    items.append(url)
        for url in items:
            self.queue.add({"url": url})
            self._append_log(f"[Queued] {url}")
        self.url_text.delete("1.0", tk.END)

    def _on_start(self):
        # Run in background thread to avoid freezing UI
        t = threading.Thread(target=self.queue.start, daemon=True)
        t.start()

    def _on_stop(self):
        self.queue.stop()

    def _on_load_links(self):
        path = filedialog.askopenfilename(title="Select links file", filetypes=[("Text Files", "*.txt"), ("All Files", "*.*")])
        if not path:
            return
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                count = 0
                for line in f:
                    url = line.strip()
                    if url:
                        self.queue.add({"url": url})
                        count += 1
                self._append_log(f"[Links] {count} URLs queued from file")
        except Exception as e:
            messagebox.showerror("Error", f"Cannot load links file:\n{e}")

    def _on_status(self, item: dict, status: str):
        # Rebuild list simple approach
        def _refresh():
            self.queue_list.delete(0, tk.END)
            # Access to internal queue items is indirect; we only know latest item status.
            # For a better model, you'd maintain a shared list in the queue.
            # Here we just append the latest status line.
            self.queue_list.insert(tk.END, f"{status} - {item.get('url','')}")
        self.after(0, _refresh)


if __name__ == "__main__":
    app = App()
    app.mainloop()


