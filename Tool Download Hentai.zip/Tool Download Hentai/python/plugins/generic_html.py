from bs4 import BeautifulSoup
from utils.http import get


class GenericHtmlPlugin:
    def matches(self, url: str) -> bool:
        return True

    def fetch_images(self, url: str) -> dict:
        html, _ = get(url)
        soup = BeautifulSoup(html, "html.parser")
        title = (soup.title.string or "untitled").strip() if soup.title else "untitled"
        images: list[str] = []
        for img in soup.select("img[src]"):
            src = img["src"].strip()
            if src.startswith("http://") or src.startswith("https://"):
                images.append(src)
            elif src.startswith("//"):
                scheme = "https" if url.startswith("https://") else "http"
                images.append(f"{scheme}:{src}")
            elif src.startswith("/"):
                # origin
                import urllib.parse as up
                u = up.urlparse(url)
                origin = f"{u.scheme}://{u.netloc}"
                images.append(origin + src)
        if not images:
            raise ValueError("No images found on page")
        return {"title": title, "images": images}

    def sanitize_title(self, title: str) -> str:
        return title


