import os
import re


def join(a: str, b: str) -> str:
    return os.path.join(a, b)


def sanitize(name: str) -> str:
    rep = re.sub(r'[\\/:*?"<>|]', '_', name).rstrip()
    return rep or "untitled"


def mkdir_p(path: str):
    os.makedirs(path, exist_ok=True)


def guess_ext(url: str) -> str:
    # crude guess
    for ext in ("jpg", "jpeg", "png", "webp", "gif"):
        if ("." + ext) in url.lower():
            return ext
    return "jpg"


