from typing import Tuple

import requests


DEFAULT_HEADERS = {
    "User-Agent": "PythonDownloader/1.0",
    "Accept": "*/*",
}


def get(url: str, headers: dict | None = None) -> tuple[str, int]:
    resp = requests.get(url, headers=headers or DEFAULT_HEADERS, timeout=30)
    resp.raise_for_status()
    return resp.text, resp.status_code


def download_to_file(url: str, filepath: str, headers: dict | None = None) -> Tuple[bool, str | None]:
    try:
        with requests.get(url, headers=headers or DEFAULT_HEADERS, stream=True, timeout=60) as r:
            r.raise_for_status()
            with open(filepath, "wb") as f:
                for chunk in r.iter_content(chunk_size=1024 * 64):
                    if chunk:
                        f.write(chunk)
        return True, None
    except Exception as e:
        return False, str(e)


