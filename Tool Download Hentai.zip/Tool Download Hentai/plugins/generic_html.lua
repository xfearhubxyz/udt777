local M = {}

function M:matches(url)
    -- Generic handler is fallback; return false to let site-specific plugins take precedence
    return true
end

local function extract_title(html)
    local t = html:match('<title>(.-)</title>') or 'untitled'
    t = t:gsub('\n', ' '):gsub('\r', ' ')
    return t
end

local function extract_images(html, base_url)
    local images = {}
    for src in html:gmatch('<img[^>]-src=["\\\'](.-)["\\\']') do
        if src:match('^https?://') then
            table.insert(images, src)
        elseif src:sub(1,2) == '//' then
            local scheme = base_url:match('^(https?)://') or 'https'
            table.insert(images, scheme .. ':' .. src)
        elseif src:sub(1,1) == '/' then
            local origin = base_url:match('^(https?://[^/]+)') or ''
            table.insert(images, origin .. src)
        end
    end
    return images
end

function M:fetch_images(url, http)
    local body, code = http.get(url)
    assert(body and (tostring(code) == '200' or code == 200), 'Failed to fetch page: ' .. tostring(code))
    local title = extract_title(body)
    local images = extract_images(body, url)
    assert(#images > 0, 'No images found on page')
    return {
        title = title,
        images = images
    }
end

function M:sanitize_title(title)
    return title
end

return M


