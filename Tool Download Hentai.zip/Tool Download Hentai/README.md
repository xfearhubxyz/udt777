Hentai/Manga Downloader (Lua + IUP)

Overview
This is a Lua-based GUI downloader inspired by the feature set of HDoujin Downloader (reference: `https://doujindownloader.com/comment-page-47/`). It provides a queue-based GUI, modular site plugins, and a basic Generic HTML plugin that can extract images from simple gallery pages.

Important Note
- This is an MVP. Sites protected by Cloudflare/captcha or dynamic JS rendering will require per-site plugins and/or cookie import. The Generic HTML plugin works on simple pages where images are directly present in the source.

Features (MVP)
- GUI (IUP): URL input, Add to Queue, Start, Stop, per-item status
- Modular plugin system (place Lua files in `plugins/`)
- Generic HTML plugin: extracts <img src> URLs and downloads to a folder
- Concurrent downloads with retries
- Basic metadata and folder naming

Requirements (Windows)
1) Lua 5.3+ or LuaJIT
2) LuaRocks
3) Dependencies:
   - luasocket (HTTP)
   - luasec (HTTPS)
   - luafilesystem (filesystem)
   - iuplua (GUI)

Install (LuaRocks)
  luarocks install luasocket
  luarocks install luasec
  luarocks install luafilesystem
  luarocks install iuplua

Run
  lua main.lua

If IUP isn’t available, the app will fall back to a simple console mode where you can paste a URL to test the downloader (limited flow).

Folder Structure
- main.lua                    (entry point with GUI)
- downloader.lua              (queue, workers, retries)
- utils/http.lua              (HTTP helpers)
- utils/fs.lua                (filesystem helpers)
- plugins/generic_html.lua    (basic image extractor)
- downloads/                  (output directory)

Usage
1) Launch the app: lua main.lua
2) Paste one or many URLs (newline or comma separated) and press Add, or use "Load Links (.txt)" to load from a text file (one URL per line).
3) Press Start to begin downloads (MVP runs sequentially and UI may freeze while downloading).
4) Files are saved under downloads/<title>.

JPG-only Mode
- The downloader filters to only .jpg/.jpeg image URLs and saves all files with .jpg extension.

External Lua Plugins (Runtime Load)
- In the Lua GUI, click "Load Plugin (.lua)" and pick a Lua file that returns a table implementing:
  - matches(url): boolean
  - fetch_images(url, http): returns { title = string, images = { string, ... } }
  - sanitize_title(title): optional
- After loading, new URLs matching your plugin will be handled by it.

Detailed Logs
- The log panel now shows timestamps, fetch steps, per-image saves (bytes + HTTP code), retries, and errors.

Extending (Plugins)
- Add a file under plugins/<site>.lua exporting:
  - matches(url): boolean
  - fetch_chapter_list(url, http): list of chapters (optional; can be single)
  - fetch_images(chapter_url, http): returns { title = ..., images = { ... } }
  - sanitize_title(title): optional

Legal
- Use responsibly. Respect site terms and local laws.

Reference
- Features inspired by HDoujin Downloader: `https://doujindownloader.com/comment-page-47/`

Python GUI (Tkinter)
Requirements
- Python 3.10+
- Pip packages:
  - requests
  - beautifulsoup4

Install
  pip install -r python/requirements.txt

Run
  python python/app.py

Usage
1) Paste one or many URLs into the multi-line box (newline or comma separated) and press Add; or click "Load Links (.txt)" to import a list (one URL per line)
2) Press Start to begin downloads (runs in background threads). Press Stop to signal stop.
3) Files are saved under downloads/<title>

JPG-only Mode (Python)
- Only .jpg/.jpeg images are downloaded and saved as .jpg files.


