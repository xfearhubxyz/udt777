local http = require('utils.http')
local fs = require('utils.fs')
local logfmt = require('utils.log')

local M = {}

local function load_plugins()
    local plugins = {}
    local ok, lfs = pcall(require, 'lfs')
    if not ok then return plugins end
    local base = 'plugins'
    for file in lfs.dir(base) do
        if file:match('%.lua$') then
            local name = file:gsub('%.lua$', '')
            local mod = require('plugins.' .. name)
            table.insert(plugins, mod)
        end
    end
    return plugins
end

local function pick_plugin(plugins, url)
    for _, p in ipairs(plugins) do
        if p.matches and p:matches(url) then
            return p
        end
    end
    return require('plugins.generic_html')
end

local Queue = {}
Queue.__index = Queue

function Queue:add(item)
    local entry = { url = item.url, status = 'queued', retries = 0 }
    table.insert(self.items, entry)
    if self.on_status then self.on_status(entry, 'queued') end
    if self.on_log then self.on_log(logfmt.prefix(string.format('[Add] %s', item.url))) end
end

function Queue:start()
    if self.running then return end
    self.running = true
    if self.on_log then self.on_log(logfmt.prefix('[Start] Downloading...')) end
end

function Queue:stop()
    self.running = false
    if self.on_log then self.on_log(logfmt.prefix('[Stop] Stopped.')) end
end

function Queue:wait_until_idle()
    -- For console mode where we call run_all, this returns immediately after completion
end

function Queue:_next_item()
    for _, it in ipairs(self.items) do
        if it.status == 'queued' then
            it.status = 'downloading'
            if self.on_status then self.on_status(it, 'downloading') end
            return it
        end
    end
    return nil
end

-- Workers removed in MVP; sequential processing for reliability

function Queue:_process_item(it)
    local plugins = self.plugins
    local plugin = pick_plugin(plugins, it.url)
    local ok, err = pcall(function()
        if self.on_log then self.on_log(logfmt.prefix('[Fetch] ' .. it.url)) end
        local job = plugin:fetch_images(it.url, http)
        local title = job.title or 'untitled'
        if plugin.sanitize_title then
            title = plugin:sanitize_title(title)
        end
        local out_dir = fs.join(self.download_dir, fs.sanitize(title))
        fs.mkdir_p(out_dir)
        local images = job.images or {}
        -- JPG-only filter
        local jpg_images = {}
        for _, u in ipairs(images) do
            local lu = string.lower(u)
            if lu:match('%.jpe?g[%?%#]?') then table.insert(jpg_images, u) end
        end
        if self.on_log then self.on_log(logfmt.prefix(string.format('[Images] %d found (%d jpg)', #images, #jpg_images))) end
        for idx, img_url in ipairs(jpg_images) do
            local filename = string.format('%04d.%s', idx, 'jpg')
            local dest = fs.join(out_dir, filename)
            if self.on_log then self.on_log(logfmt.prefix(string.format('  [Get] %s', img_url))) end
            local okdl, reason, code = http.download_to_file(img_url, dest)
            if not okdl then
                if self.on_log then self.on_log(logfmt.prefix(string.format('  [Fail] %s (%s)', img_url, tostring(reason)))) end
            end
            local attr = io.open(dest, 'rb')
            local bytes = 0
            if attr then
                attr:seek('end')
                bytes = attr:seek()
                attr:close()
            end
            if self.on_log then self.on_log(logfmt.prefix(string.format('  [Saved] %s (%d bytes, HTTP %s)', filename, bytes, tostring(code or 'ok')))) end
        end
        it.status = 'done'
        if self.on_status then self.on_status(it, 'done') end
        if self.on_log then self.on_log(logfmt.prefix('[Done] ' .. title)) end
    end)
    if not ok then
        it.retries = it.retries + 1
        if it.retries <= self.max_retries then
            it.status = 'queued'
            if self.on_status then self.on_status(it, 'retry') end
            if self.on_log then self.on_log(logfmt.prefix(string.format('[Retry %d/%d] %s: %s', it.retries, self.max_retries, it.url, tostring(err)))) end
        else
            it.status = 'failed'
            if self.on_status then self.on_status(it, 'failed') end
            if self.on_log then self.on_log(logfmt.prefix(string.format('[Error] %s', tostring(err)))) end
        end
    end
end

function Queue:run_all()
    self:start()
    while self.running do
        local it = self:_next_item()
        if not it then break end
        self:_process_item(it)
    end
    self:stop()
end

function M.create_queue(opts)
    local q = setmetatable({}, Queue)
    q.items = {}
    q.concurrency = 1 -- sequential in MVP
    q.max_retries = opts.max_retries or 2
    q.download_dir = opts.download_dir or 'downloads'
    q.on_log = opts.on_log
    q.on_status = opts.on_status
    q.plugins = load_plugins()
    fs.mkdir_p(q.download_dir)
    return q
end

function M.add_external_plugin(q, filepath)
    local ok, mod_or_err = pcall(dofile, filepath)
    if not ok then error('Failed to load plugin: ' .. tostring(mod_or_err)) end
    local mod = mod_or_err
    if type(mod) ~= 'table' or type(mod.matches) ~= 'function' or type(mod.fetch_images) ~= 'function' then
        error('Invalid plugin module. Expect table with :matches(url) and :fetch_images(url, http)')
    end
    table.insert(q.plugins, mod)
    if q.on_log then q.on_log(logfmt.prefix('[Plugin] Loaded: ' .. filepath)) end
end

return M


