local has_iup, iup = pcall(require, 'iuplua')

local downloader = require('downloader')
local fs = require('utils.fs')
local logfmt = require('utils.log')

local function run_console()
    print('[Info] IUP not found; running in console mode.')
    io.write('Enter URL: ')
    local url = io.read('*l')
    if not url or url == '' then
        print('No URL provided. Exiting.')
        return
    end
    local item = { url = url }
    local queue = downloader.create_queue({ concurrency = 1, download_dir = 'downloads' })
    queue:add(item)
    queue:run_all()
    print('Done.')
end

if not has_iup then
    run_console()
    os.exit(0)
end

-- GUI Mode
local url_text = iup.text{ expand = 'HORIZONTAL', visiblecolumns = 60 }
local add_btn = iup.button{ title = 'Add' }
local start_btn = iup.button{ title = 'Start' }
local stop_btn = iup.button{ title = 'Stop' }
local load_plugin_btn = iup.button{ title = 'Load Plugin (.lua)' }
local load_list_btn = iup.button{ title = 'Load Links (.txt)' }
local queue_list = iup.list{ expand = 'YES', DROPDOWN = 'NO', MULTIPLE = 'NO' }
local status_multiline = iup.multiline{ readonly = 'YES', expand = 'YES', wordwrap = 'YES' }

local queue = downloader.create_queue({ concurrency = 3, download_dir = 'downloads', on_log = function(msg)
    status_multiline.append = msg .. '\n'
end, on_status = function(item, status)
    -- rebuild list each time for simplicity
    queue_list.removeitem = 'ALL'
    local i = 1
    for _, it in ipairs(queue.items) do
        local label = string.format('%s  -  %s', it.status, it.url)
        queue_list[i] = label
        i = i + 1
    end
end })

local function log(msg)
    if queue and queue.on_log then queue.on_log(logfmt.prefix(msg)) end
end

function add_btn:action()
    local raw = url_text.value or ''
    if raw == '' then return end
    -- Allow multi-URL input separated by newline or comma
    for url in string.gmatch(raw, '[^\n,]+') do
        url = (url or ''):match('^%s*(.-)%s*$')
        if url ~= '' then
            queue:add({ url = url })
            log('[Queued] ' .. url)
        end
    end
    url_text.value = ''
end

function start_btn:action()
    -- Sequential run; UI will block during downloads in MVP
    queue:run_all()
end

function stop_btn:action()
    queue:stop()
end

function load_plugin_btn:action()
    local fd = iup.filedlg{ dialogtype = 'OPEN', title = 'Select Lua Plugin', filter = '*.lua', filterinfo = 'Lua files' }
    fd:popup(iup.ANYWHERE, iup.ANYWHERE)
    if fd.status == '0' and fd.value and fd.value ~= '' then
        local path = fd.value
        local ok, err = pcall(function()
            downloader.add_external_plugin(queue, path)
        end)
        if not ok then
            log('[Plugin] Load failed: ' .. tostring(err))
        end
    end
end

function load_list_btn:action()
    local fd = iup.filedlg{ dialogtype = 'OPEN', title = 'Select links file (.txt)', filter = '*.txt', filterinfo = 'Text files' }
    fd:popup(iup.ANYWHERE, iup.ANYWHERE)
    if fd.status == '0' and fd.value and fd.value ~= '' then
        local f = io.open(fd.value, 'r')
        if not f then
            log('[Links] Cannot open file: ' .. tostring(fd.value))
            return
        end
        local count = 0
        for line in f:lines() do
            local url = (line or ''):match('^%s*(.-)%s*$')
            if url ~= '' then
                queue:add({ url = url })
                count = count + 1
            end
        end
        f:close()
        log(string.format('[Links] %d URLs queued from file', count))
    end
end

local left_panel = iup.vbox{
    iup.label{ title = 'Queue' },
    queue_list;
    gap = 4
}

local right_panel = iup.vbox{
    iup.label{ title = 'Logs' },
    status_multiline;
    gap = 4
}

local top_controls = iup.hbox{ url_text, add_btn, start_btn, stop_btn, load_list_btn, load_plugin_btn; gap = 8; margin = '8x8' }

local body = iup.hbox{ left_panel, right_panel; gap = 8, margin = '8x8' }

local vbox = iup.vbox{ top_controls, body; gap = 8 }

local dlg = iup.dialog{
    vbox; title = 'Lua Manga/Doujin Downloader', size = 'HALFxHALF'
}

dlg:show()
if iup.MainLoopLevel() == 0 then
    iup.MainLoop()
end


