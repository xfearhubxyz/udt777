local M = {}

local ok_lfs, lfs = pcall(require, 'lfs')

function M.join(a, b)
    local sep = package.config:sub(1,1)
    if a:sub(-1) == sep then return a .. b end
    return a .. sep .. b
end

function M.sanitize(name)
    local rep = name
    rep = rep:gsub('[\\/:*?"<>|]', '_')
    rep = rep:gsub('%s+$', '')
    if rep == '' then rep = 'untitled' end
    return rep
end

function M.mkdir_p(path)
    if ok_lfs then
        local sep = package.config:sub(1,1)
        local current = ''
        if sep == '\\' then
            -- Windows drive handling
            if path:match('^%a:[\\/]') then
                current = path:sub(1,3)
                path = path:sub(4)
            end
        end
        for part in string.gmatch(path, '[^' .. sep .. ']+') do
            if current == '' then current = part else current = current .. sep .. part end
            local attr = lfs.attributes(current)
            if not attr then lfs.mkdir(current) end
        end
    else
        -- Best-effort single mkdir
        os.execute((package.config:sub(1,1) == '\\') and ('mkdir "%s" >nul 2>nul'):format(path) or ('mkdir -p "%s"'):format(path))
    end
end

return M


