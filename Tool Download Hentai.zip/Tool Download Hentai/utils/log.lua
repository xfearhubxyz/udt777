local M = {}

local function now()
    return os.date('%Y-%m-%d %H:%M:%S')
end

function M.prefix(msg)
    return string.format('[%s] %s', now(), msg)
end

return M


