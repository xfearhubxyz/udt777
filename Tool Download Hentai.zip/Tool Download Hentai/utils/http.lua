local http = {}

local has_socket, socket_http = pcall(require, 'socket.http')
local has_https, https = pcall(require, 'ssl.https')
local ltn12 = require('ltn12')

local function pick_client(url)
    if url:match('^https://') and has_https then
        return https
    end
    return socket_http
end

function http.get(url, headers)
    local client = pick_client(url)
    assert(client, 'No HTTP/HTTPS client available. Install luasocket + luasec.')
    local resp = {}
    local ok, code, hdrs, status = client.request{
        url = url,
        headers = headers or {
            ['User-Agent'] = 'LuaDownloader/1.0',
            ['Accept'] = '*/*'
        },
        sink = ltn12.sink.table(resp)
    }
    if not ok then return nil, code end
    return table.concat(resp), code, hdrs, status
end

function http.download_to_file(url, filepath, headers)
    local client = pick_client(url)
    assert(client, 'No HTTP/HTTPS client available. Install luasocket + luasec.')
    local file, ferr = io.open(filepath, 'wb')
    if not file then return false, ferr end
    local ok, code, hdrs, status = client.request{
        url = url,
        headers = headers or {
            ['User-Agent'] = 'LuaDownloader/1.0',
            ['Accept'] = '*/*'
        },
        sink = ltn12.sink.file(file)
    }
    if not ok or (type(code) == 'number' and code >= 400) then
        return false, status or code, code
    end
    return true, nil, code
end

return http


