require "MangaXyz"

function Register()

    module.Name = 'ManhuaScan'
    module.Language = 'en'

    module.Domains.Add('kaliscan.com')
    module.Domains.Add('manhuascan.com')
    module.Domains.Add('manhuascan.io')
    module.Domains.Add('manhuascan.me')

end
