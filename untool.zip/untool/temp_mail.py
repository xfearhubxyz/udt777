import random
import string
import time
from typing import Optional, Tuple
import requests

ONESECMAIL_API = "https://www.1secmail.com/api/v1/"
AVAILABLE_DOMAINS = [
	"1secmail.com",
	"1secmail.org",
	"1secmail.net",
	"kzccv.com",
	"wwjmp.com",
	"esiix.com",
]

# Alternative service: mail.tm
MAILTM_API = "https://api.mail.tm"


def generate_random_login(length: int = 10) -> str:
	alphabet = string.ascii_lowercase + string.digits
	return "".join(random.choice(alphabet) for _ in range(length))


def create_temp_address() -> tuple[str, str, str]:
	"""Return (login, domain, email). ALWAYS use mail.tm only."""
	max_retries = 3
	for attempt in range(max_retries):
		try:
			if attempt > 0:
				wait_time = attempt * 2  # Progressive delay: 2s, 4s
				print(f"⏳ Waiting {wait_time}s before retry...")
				time.sleep(wait_time)
			
			print(f"📧 Creating mail.tm address (attempt {attempt + 1}/{max_retries})...")
			return create_mailtm_address()
			
		except requests.exceptions.HTTPError as e:
			if "429" in str(e):  # Too Many Requests
				print(f"⚠️ mail.tm rate limit hit (attempt {attempt + 1}/{max_retries})")
				if attempt < max_retries - 1:
					time.sleep(5)  # Longer wait for rate limits
					continue
			print(f"❌ mail.tm error: {str(e)[:80]}")
			if attempt == max_retries - 1:
				raise
		except Exception as e:
			print(f"❌ mail.tm error: {str(e)[:80]}")
			if attempt == max_retries - 1:
				raise
	
	raise RuntimeError("Failed to create mail.tm address after all retries")


def create_mailtm_address() -> Tuple[str, str, str]:
	"""Create a mail.tm address. Returns (login, domain, email) for compatibility."""
	# Get available domains
	resp = requests.get(f"{MAILTM_API}/domains", timeout=15)
	resp.raise_for_status()
	domains = resp.json().get("hydra:member", [])
	if not domains:
		raise RuntimeError("No mail.tm domains available")
	domain = domains[0]["domain"]
	
	# Create account
	login = generate_random_login(12)
	email = f"{login}@{domain}"
	password = generate_random_login(16)
	
	account_resp = requests.post(
		f"{MAILTM_API}/accounts",
		json={"address": email, "password": password},
		timeout=15
	)
	account_resp.raise_for_status()
	
	# Get auth token
	token_resp = requests.post(
		f"{MAILTM_API}/token",
		json={"address": email, "password": password},
		timeout=15
	)
	token_resp.raise_for_status()
	token = token_resp.json()["token"]
	
	# Store token globally for later use
	global _mailtm_token, _mailtm_email
	_mailtm_token = token
	_mailtm_email = email
	
	print(f"✅ mail.tm: {email}")
	return login, domain, email


_mailtm_token = None
_mailtm_email = None


def _api_get(action: str, **params):
	"""1secmail API wrapper."""
	resp = requests.get(ONESECMAIL_API, params={"action": action, **params}, timeout=15)
	resp.raise_for_status()
	return resp.json()


def _get_mailtm_messages():
	"""Get messages from mail.tm."""
	if not _mailtm_token:
		return []
	headers = {"Authorization": f"Bearer {_mailtm_token}"}
	resp = requests.get(f"{MAILTM_API}/messages", headers=headers, timeout=10)
	resp.raise_for_status()
	return resp.json().get("hydra:member", [])


def _read_mailtm_message(msg_id: str) -> dict:
	"""Read a specific mail.tm message."""
	if not _mailtm_token:
		raise RuntimeError("No mail.tm token")
	headers = {"Authorization": f"Bearer {_mailtm_token}"}
	resp = requests.get(f"{MAILTM_API}/messages/{msg_id}", headers=headers, timeout=10)
	resp.raise_for_status()
	msg = resp.json()
	
	# Extract from address properly
	from_addr = ""
	from_field = msg.get("from", {})
	if isinstance(from_field, dict):
		from_addr = from_field.get("address", "")
	elif isinstance(from_field, str):
		from_addr = from_field
	
	# Extract HTML and text - handle if they are lists or single items
	html_body = msg.get("html", [])
	if isinstance(html_body, list):
		html_body = " ".join(html_body) if html_body else ""
	
	text_body = msg.get("text", "")
	if isinstance(text_body, list):
		text_body = " ".join(text_body) if text_body else ""
	
	# Convert to 1secmail format
	return {
		"id": msg["id"],
		"from": from_addr,
		"subject": msg.get("subject", ""),
		"textBody": text_body,
		"htmlBody": html_body,
	}


def poll_for_message(login: str, domain: str, predicate, timeout_seconds: int = 180, poll_interval_seconds: float = 3.0) -> Optional[dict]:
	"""Poll inbox and return the first message dict that matches predicate or None on timeout."""
	end_time = time.time() + timeout_seconds
	is_mailtm = _mailtm_email and f"{login}@{domain}" == _mailtm_email
	
	while time.time() < end_time:
		try:
			if is_mailtm:
				messages = _get_mailtm_messages()
				for msg in messages:
					# Convert to 1secmail-like format for predicate
					msg_compat = {
						"id": msg["id"],
						"from": msg.get("from", {}).get("address", ""),
						"subject": msg.get("subject", ""),
					}
					if predicate(msg_compat):
						return msg_compat
			else:
				messages = _api_get("getMessages", login=login, domain=domain)
				for msg in messages:
					if predicate(msg):
						return msg
		except Exception as e:
			print(f"Error polling inbox: {e}")
		time.sleep(poll_interval_seconds)
	return None


def read_message(login: str, domain: str, message_id) -> dict:
	"""Read a message by ID. Works for both 1secmail and mail.tm."""
	is_mailtm = _mailtm_email and f"{login}@{domain}" == _mailtm_email
	if is_mailtm:
		return _read_mailtm_message(message_id)
	else:
		return _api_get("readMessage", login=login, domain=domain, id=message_id)
