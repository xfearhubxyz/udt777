## Undress.app email-login automation (Windows)

### Setup

```powershell
python -m venv .venv
. .venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

Chrome must be installed. The script uses undetected-chromedriver.

### Run

```powershell
python .\undress_login.py
```

- Opens `https://undress.app/ref/97c2267e8d7c4237af6bd07d`
- Clicks "Try now for free"
- Chooses Email login
- Uses a temporary email (1secmail) and submits it
- Waits for the email and automatically opens `https://undress.app/loginEmail?token=...`

You can override the referral URL with env var `UNDRESS_REF_URL`.
