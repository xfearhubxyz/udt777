import discord
from discord.ext import commands
from discord import app_commands
import asyncio
from typing import Optional
import config
from email_manager import EmailManager

# Intents configuration
intents = discord.Intents.default()
intents.message_content = True
intents.guilds = True

# Bot setup
bot = commands.Bot(command_prefix='!', intents=intents)
email_manager = EmailManager(config.EMAIL_PREFIX, config.EMAIL_DOMAIN, config.STARTING_NUMBER)

# Dictionary để lưu monitoring tasks
monitoring_tasks = {}

class EmailButton(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)  # Persistent view
    
    @discord.ui.button(label="📧 Tạo Email Mới", style=discord.ButtonStyle.success, custom_id="create_email", row=0)
    async def create_email_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Button để tạo email mới"""
        # Check if interaction is already responded to
        if interaction.response.is_done():
            print("⚠️  Interaction already responded, skipping...")
            return
        
        try:
            # Defer immediately (within 3 seconds)
            await interaction.response.defer(ephemeral=True)
            print(f"✅ Interaction deferred for user {interaction.user.name}")
        except discord.errors.InteractionResponded:
            print("⚠️  Interaction already responded (caught exception)")
            return
        except Exception as e:
            print(f"❌ Error deferring interaction: {e}")
            return
        
        try:
            # Tạo email address mới
            email = email_manager.generate_email_address()
            print(f"📧 Creating email: {email}")
            
            # Tạo session cho email (có retry logic, có thể mất ~100s)
            result = await email_manager.create_email_session(email)
            
            if 'error' in result:
                await interaction.followup.send(
                    f"❌ **Lỗi tạo email:**\n{result['error']}", 
                    ephemeral=True
                )
                return
            
            # Tạo embed thông báo
            embed = discord.Embed(
                title="✅ Email Đã Được Tạo",
                description=f"Email mới của bạn đã sẵn sàng!",
                color=discord.Color.green()
            )
            embed.add_field(name="📧 Email Address", value=f"`{email}`", inline=False)
            embed.add_field(name="🌐 Truy cập", value=f"[generator.email/{email}](https://generator.email/{email})", inline=False)
            embed.add_field(name="📊 Email số", value=f"#{email_manager.current_number - 1:03d}", inline=True)
            embed.add_field(name="⏰ Đang theo dõi", value="✅ Đã bật", inline=True)
            embed.set_footer(text="Bot sẽ tự động thông báo khi có email mới hoặc OTP")
            
            # Start monitoring
            task = asyncio.create_task(
                email_manager.monitor_email(email, lambda msg: handle_new_message(interaction, msg))
            )
            monitoring_tasks[email] = task
            
            # Tạo view với nút stop monitoring
            stop_view = StopMonitoringView(email)
            
            await interaction.followup.send(embed=embed, view=stop_view, ephemeral=True)
            print(f"✅ Email {email} created and monitoring started")
            
        except discord.errors.NotFound:
            print("❌ Interaction expired (404 Unknown interaction)")
            # Clean up if needed
            if email in monitoring_tasks:
                monitoring_tasks[email].cancel()
                del monitoring_tasks[email]
        except Exception as e:
            print(f"❌ Error in create_email_button: {e}")
            try:
                await interaction.followup.send(
                    f"❌ **Lỗi không mong đợi:**\n{str(e)[:200]}", 
                    ephemeral=True
                )
            except:
                pass
    
    @discord.ui.button(label="📬 Kiểm Tra Mail", style=discord.ButtonStyle.primary, custom_id="check_mail", row=0)
    async def check_mail_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Button để kiểm tra mail đã tạo"""
        if interaction.response.is_done():
            return
        
        try:
            await interaction.response.defer(ephemeral=True)
        except discord.errors.InteractionResponded:
            return
        except Exception as e:
            print(f"❌ Error deferring check mail interaction: {e}")
            return
        
        try:
            # Lấy danh sách emails đã tạo (từ 0 đến current_number - 1)
            max_emails = min(email_manager.current_number, 25)  # Discord limit 25 options
            
            if max_emails == 0:
                await interaction.followup.send(
                    "❌ **Chưa có email nào được tạo!**\n"
                    "Nhấn nút **Tạo Email Mới** để tạo email đầu tiên.",
                    ephemeral=True
                )
                return
            
            # Tạo select menu với danh sách emails
            select_view = EmailSelectView(max_emails)
            
            embed = discord.Embed(
                title="📬 Chọn Email Để Kiểm Tra",
                description=f"Chọn số email từ dropdown bên dưới:",
                color=discord.Color.blue()
            )
            embed.add_field(
                name="📊 Tổng số email đã tạo",
                value=f"`{email_manager.current_number}` emails",
                inline=False
            )
            embed.set_footer(text="Email sẽ được check inbox ngay sau khi chọn")
            
            await interaction.followup.send(embed=embed, view=select_view, ephemeral=True)
            
        except Exception as e:
            print(f"❌ Error in check_mail_button: {e}")
            try:
                await interaction.followup.send(
                    f"❌ **Lỗi:**\n{str(e)[:200]}", 
                    ephemeral=True
                )
            except:
                pass

class EmailSelectView(discord.ui.View):
    def __init__(self, max_number: int):
        super().__init__(timeout=180)  # 3 minutes timeout
        self.max_number = max_number
        
        # Tạo options cho select menu
        options = []
        for i in range(max_number):
            email = f"{config.EMAIL_PREFIX}{i:03d}@{config.EMAIL_DOMAIN}"
            options.append(
                discord.SelectOption(
                    label=f"Email #{i:03d}",
                    description=email,
                    value=str(i),
                    emoji="📧"
                )
            )
        
        # Thêm select menu
        select = discord.ui.Select(
            placeholder=f"Chọn email (000-{max_number-1:03d})",
            options=options,
            custom_id="email_select"
        )
        select.callback = self.select_callback
        self.add_item(select)
    
    async def select_callback(self, interaction: discord.Interaction):
        """Callback khi user chọn email"""
        if interaction.response.is_done():
            return
        
        try:
            await interaction.response.defer(ephemeral=True)
        except:
            return
        
        try:
            # Lấy số email được chọn
            email_number = int(interaction.data['values'][0])
            email = f"{config.EMAIL_PREFIX}{email_number:03d}@{config.EMAIL_DOMAIN}"
            
            print(f"📬 Checking inbox for: {email}")
            
            # Check if email session exists
            if email not in email_manager.active_emails:
                # Tạo session nếu chưa có
                result = await email_manager.create_email_session(email)
                if 'error' in result:
                    await interaction.followup.send(
                        f"❌ **Không thể kết nối đến email:**\n{result['error']}", 
                        ephemeral=True
                    )
                    return
            
            # Check for messages
            messages = await email_manager.check_for_messages(email)
            
            # Tạo embed hiển thị inbox
            embed = discord.Embed(
                title=f"📬 Inbox: {email}",
                description=f"Đang kiểm tra hộp thư...",
                color=discord.Color.blue()
            )
            
            if messages:
                embed.description = f"Tìm thấy **{len(messages)}** email(s)"
                
                for i, msg in enumerate(messages[:5], 1):  # Hiển thị tối đa 5 emails
                    subject = msg.get('subject', 'No Subject')[:100]
                    sender = msg.get('from', 'Unknown')[:50]
                    content = msg.get('content', '')[:150]
                    
                    # Tìm OTP trong message
                    full_text = f"{subject} {content}"
                    otp = email_manager.extract_otp_from_message(full_text)
                    
                    otp_text = f"🔐 **OTP: {otp}**\n" if otp else ""
                    
                    embed.add_field(
                        name=f"📨 Email #{i}: {subject}",
                        value=f"📤 Từ: {sender}\n{otp_text}📄 {content[:100]}...",
                        inline=False
                    )
            else:
                embed.description = "📭 **Inbox trống**\n\nChưa có email nào trong hộp thư này."
            
            embed.add_field(
                name="🌐 Truy cập trực tiếp",
                value=f"[generator.email/{email}](https://generator.email/{email})",
                inline=False
            )
            embed.set_footer(text=f"Email #{email_number:03d} • Cập nhật: {messages[0].get('id', 'N/A') if messages else 'Empty'}")
            
            # Tạo view với nút Start/Stop Monitoring
            action_view = EmailActionView(email)
            
            await interaction.followup.send(embed=embed, view=action_view, ephemeral=True)
            print(f"✅ Inbox checked for {email}: {len(messages)} message(s)")
            
        except Exception as e:
            print(f"❌ Error in select_callback: {e}")
            try:
                await interaction.followup.send(
                    f"❌ **Lỗi:**\n{str(e)[:200]}", 
                    ephemeral=True
                )
            except:
                pass

class EmailActionView(discord.ui.View):
    def __init__(self, email: str):
        super().__init__(timeout=180)
        self.email = email
    
    @discord.ui.button(label="🔄 Refresh Inbox", style=discord.ButtonStyle.primary, custom_id="refresh_inbox")
    async def refresh_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Button để refresh inbox"""
        if interaction.response.is_done():
            return
        
        try:
            await interaction.response.defer(ephemeral=True)
        except:
            return
        
        try:
            messages = await email_manager.check_for_messages(self.email)
            
            embed = discord.Embed(
                title=f"📬 Inbox: {self.email}",
                description=f"🔄 **Đã refresh!**",
                color=discord.Color.green()
            )
            
            if messages:
                embed.description = f"Tìm thấy **{len(messages)}** email(s)"
                
                for i, msg in enumerate(messages[:5], 1):
                    subject = msg.get('subject', 'No Subject')[:100]
                    sender = msg.get('from', 'Unknown')[:50]
                    content = msg.get('content', '')[:150]
                    
                    full_text = f"{subject} {content}"
                    otp = email_manager.extract_otp_from_message(full_text)
                    
                    otp_text = f"🔐 **OTP: {otp}**\n" if otp else ""
                    
                    embed.add_field(
                        name=f"📨 Email #{i}: {subject}",
                        value=f"📤 Từ: {sender}\n{otp_text}📄 {content[:100]}...",
                        inline=False
                    )
            else:
                embed.description = "📭 **Inbox trống**"
            
            await interaction.followup.send(embed=embed, ephemeral=True)
            
        except Exception as e:
            print(f"❌ Error refreshing inbox: {e}")
            await interaction.followup.send(f"❌ Lỗi: {str(e)[:200]}", ephemeral=True)
    
    @discord.ui.button(label="👁️ Bật Theo Dõi", style=discord.ButtonStyle.success, custom_id="start_monitoring")
    async def monitor_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Button để start monitoring"""
        if interaction.response.is_done():
            return
        
        try:
            await interaction.response.defer(ephemeral=True)
        except:
            return
        
        try:
            if self.email in monitoring_tasks:
                await interaction.followup.send(
                    f"⚠️ **Email này đã được theo dõi!**\n`{self.email}`", 
                    ephemeral=True
                )
                return
            
            # Start monitoring
            task = asyncio.create_task(
                email_manager.monitor_email(self.email, lambda msg: handle_new_message(interaction, msg))
            )
            monitoring_tasks[self.email] = task
            
            embed = discord.Embed(
                title="✅ Đã Bật Theo Dõi",
                description=f"Email: `{self.email}`",
                color=discord.Color.green()
            )
            embed.add_field(
                name="👁️ Trạng thái",
                value="Bot sẽ tự động thông báo khi có email mới hoặc OTP",
                inline=False
            )
            
            await interaction.followup.send(embed=embed, ephemeral=True)
            print(f"✅ Monitoring started for {self.email}")
            
        except Exception as e:
            print(f"❌ Error starting monitoring: {e}")
            await interaction.followup.send(f"❌ Lỗi: {str(e)[:200]}", ephemeral=True)

class StopMonitoringView(discord.ui.View):
    def __init__(self, email: str):
        super().__init__(timeout=None)
        self.email = email
    
    @discord.ui.button(label="🛑 Dừng Theo Dõi", style=discord.ButtonStyle.danger, custom_id="stop_monitoring_dynamic")
    async def stop_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Button để dừng theo dõi email"""
        # Check if interaction is already responded to
        if interaction.response.is_done():
            print("⚠️  Interaction already responded, skipping...")
            return
        
        try:
            await interaction.response.defer(ephemeral=True)
        except discord.errors.InteractionResponded:
            print("⚠️  Stop button interaction already responded")
            return
        except Exception as e:
            print(f"❌ Error deferring stop button interaction: {e}")
            return
        
        try:
            if not self.email:
                await interaction.followup.send("❌ Không tìm thấy email để dừng", ephemeral=True)
                return
            
            if self.email in monitoring_tasks:
                monitoring_tasks[self.email].cancel()
                del monitoring_tasks[self.email]
            
            email_manager.stop_monitoring(self.email)
            
            embed = discord.Embed(
                title="⏹️ Đã Dừng Theo Dõi",
                description=f"Đã dừng theo dõi email: `{self.email}`",
                color=discord.Color.orange()
            )
            
            await interaction.followup.send(embed=embed, ephemeral=True)
            
            # Disable button
            button.disabled = True
            try:
                await interaction.message.edit(view=self)
            except Exception as e:
                print(f"⚠️  Could not edit message to disable button: {e}")
        except Exception as e:
            print(f"❌ Error in stop_button: {e}")
            try:
                await interaction.followup.send(
                    f"❌ **Lỗi:**\n{str(e)[:200]}", 
                    ephemeral=True
                )
            except:
                pass

async def handle_new_message(interaction: discord.Interaction, message_data: dict):
    """Xử lý khi có email mới"""
    email = message_data['email']
    subject = message_data['subject']
    content = message_data['content']
    sender = message_data['sender']
    otp = message_data.get('otp')
    
    # Tạo embed cho thông báo
    # Nếu có OTP thì ưu tiên highlight
    if otp:
        embed = discord.Embed(
            title="🔑 PHÁT HIỆN MÃ OTP!",
            description=f"Email: `{email}`",
            color=discord.Color.gold()
        )
        embed.add_field(name="🔐 MÃ OTP", value=f"```\n{otp}\n```", inline=False)
    else:
        embed = discord.Embed(
            title="📨 Email Mới Nhận Được!",
            description=f"Email: `{email}`",
            color=discord.Color.blue()
        )
    
    embed.add_field(name="📤 Từ", value=sender or "Unknown", inline=True)
    embed.add_field(name="📋 Tiêu đề", value=subject[:100] or "No subject", inline=True)
    
    # Truncate content nếu quá dài
    content_preview = content[:300] + "..." if len(content) > 300 else content
    if content_preview:
        embed.add_field(name="📄 Nội dung", value=content_preview, inline=False)
    
    embed.set_footer(text=f"Email đang được theo dõi • ID: {message_data.get('message_id', 'N/A')}")
    
    # Gửi thông báo
    try:
        # Gửi DM cho user
        await interaction.user.send(embed=embed)
    except discord.Forbidden:
        # Nếu không thể DM, gửi vào channel
        if config.NOTIFICATION_CHANNEL_ID:
            channel = bot.get_channel(config.NOTIFICATION_CHANNEL_ID)
            if channel:
                await channel.send(f"{interaction.user.mention}", embed=embed)

@bot.event
async def on_ready():
    """Khi bot sẵn sàng"""
    print(f'✅ Bot đã đăng nhập: {bot.user.name} (ID: {bot.user.id})')
    print(f'📧 Email Manager initialized: {config.EMAIL_PREFIX}XXX@{config.EMAIL_DOMAIN}')
    print(f'📊 Current email number: {email_manager.current_number:03d}')
    
    # Sync slash commands (only once)
    if not hasattr(bot, '_synced'):
        try:
            synced = await bot.tree.sync()
            print(f'✅ Synced {len(synced)} command(s)')
            bot._synced = True
        except Exception as e:
            print(f'❌ Failed to sync commands: {e}')
    
    # Add persistent view (only once to prevent duplicates)
    if not hasattr(bot, '_views_added'):
        bot.add_view(EmailButton())
        bot.add_view(StopMonitoringView(""))
        bot._views_added = True
        print('✅ Persistent views registered')
    
    print('✅ Bot is ready!')
    print(f'📢 Bot đang online trong {len(bot.guilds)} server(s)')
    print(f'💡 Gõ /setup trong channel để tạo button')
    
    # Auto send menu to notification channel if configured (only once)
    if config.NOTIFICATION_CHANNEL_ID and config.NOTIFICATION_CHANNEL_ID != 0:
        if not hasattr(bot, '_menu_sent'):
            try:
                channel = bot.get_channel(config.NOTIFICATION_CHANNEL_ID)
                if channel:
                    embed = discord.Embed(
                        title="🚀 Bot Đã Online!",
                        description="Email Generator Bot đã sẵn sàng!",
                        color=discord.Color.green()
                    )
                    embed.add_field(
                        name="📋 Hướng dẫn",
                        value="Gõ `/setup` để tạo menu với buttons\nHoặc bot sẽ tự động tạo menu bên dưới!",
                        inline=False
                    )
                    
                    # Auto create button menu
                    menu_embed = discord.Embed(
                        title="📧 Email Generator Bot",
                        description="Nhấn nút bên dưới để tạo email tạm thời!",
                        color=discord.Color.blue()
                    )
                    menu_embed.add_field(
                        name="📋 Hướng dẫn",
                        value=(
                            "1️⃣ Nhấn nút **Tạo Email Mới**\n"
                            "2️⃣ Bot sẽ gửi email cho bạn (DM)\n"
                            "3️⃣ Sử dụng email để đăng ký\n"
                            "4️⃣ Bot tự động thông báo khi có OTP"
                        ),
                        inline=False
                    )
                    menu_embed.add_field(
                        name="📧 Format Email",
                        value=f"`{config.EMAIL_PREFIX}000@{config.EMAIL_DOMAIN}`",
                        inline=False
                    )
                    menu_embed.set_footer(text="Email tự động tăng số thứ tự: 000 → 001 → 002...")
                    
                    view = EmailButton()
                    
                    await channel.send(embed=embed)
                    await channel.send(embed=menu_embed, view=view)
                    bot._menu_sent = True
                    print(f'✅ Đã tự động gửi menu vào channel #{channel.name}')
            except Exception as e:
                print(f'⚠️  Không thể gửi auto menu: {e}')
        else:
            print('ℹ️  Menu đã được gửi trước đó, bỏ qua để tránh spam')

@bot.tree.command(name="setup", description="Thiết lập nút tạo email trong channel")
@app_commands.checks.has_permissions(administrator=True)
async def setup_button(interaction: discord.Interaction):
    """Slash command để tạo button trong channel"""
    embed = discord.Embed(
        title="📧 Email Generator Bot",
        description="Nhấn nút bên dưới để tạo email tạm thời!",
        color=discord.Color.blue()
    )
    embed.add_field(
        name="📋 Hướng dẫn",
        value=(
            "1️⃣ Nhấn nút **Tạo Email Mới**\n"
            "2️⃣ Bot sẽ tạo email mới cho bạn\n"
            "3️⃣ Sử dụng email để đăng ký\n"
            "4️⃣ Bot tự động thông báo khi có OTP"
        ),
        inline=False
    )
    embed.add_field(
        name="📧 Format Email",
        value=f"`{config.EMAIL_PREFIX}000@{config.EMAIL_DOMAIN}`",
        inline=False
    )
    embed.set_footer(text="Email sẽ tự động tăng số thứ tự: 000 → 001 → 002...")
    
    view = EmailButton()
    
    await interaction.response.send_message(embed=embed, view=view)

@bot.tree.command(name="status", description="Kiểm tra trạng thái bot và emails đang theo dõi")
async def status(interaction: discord.Interaction):
    """Slash command để xem status"""
    embed = discord.Embed(
        title="📊 Trạng Thái Bot",
        color=discord.Color.blue()
    )
    
    embed.add_field(
        name="📧 Email tiếp theo",
        value=f"`{config.EMAIL_PREFIX}{email_manager.current_number:03d}@{config.EMAIL_DOMAIN}`",
        inline=False
    )
    
    embed.add_field(
        name="📈 Tổng số email đã tạo",
        value=f"{email_manager.current_number}",
        inline=True
    )
    
    embed.add_field(
        name="👁️ Đang theo dõi",
        value=f"{len(monitoring_tasks)} email(s)",
        inline=True
    )
    
    if email_manager.active_emails:
        active_list = "\n".join([f"• `{email}`" for email in list(email_manager.active_emails.keys())[:10]])
        if len(email_manager.active_emails) > 10:
            active_list += f"\n... và {len(email_manager.active_emails) - 10} email khác"
        embed.add_field(name="📋 Emails đang hoạt động", value=active_list, inline=False)
    
    await interaction.response.send_message(embed=embed, ephemeral=True)

@bot.tree.command(name="reset_counter", description="Reset counter về 0 (Admin only)")
@app_commands.checks.has_permissions(administrator=True)
async def reset_counter(interaction: discord.Interaction):
    """Slash command để reset counter"""
    email_manager.current_number = config.STARTING_NUMBER
    email_manager.save_data()
    
    await interaction.response.send_message(
        f"✅ Counter đã được reset về {config.STARTING_NUMBER:03d}",
        ephemeral=True
    )

@bot.event
async def on_command_error(ctx, error):
    """Error handler"""
    if isinstance(error, commands.MissingPermissions):
        await ctx.send("❌ Bạn không có quyền sử dụng lệnh này!")

async def cleanup():
    """Cleanup khi bot tắt"""
    print("🔄 Cleaning up...")
    
    # Cancel tất cả monitoring tasks
    for task in monitoring_tasks.values():
        task.cancel()
    
    # Close email manager session
    await email_manager.close_session()
    
    print("✅ Cleanup completed")

@bot.event
async def on_disconnect():
    """Khi bot disconnect"""
    await cleanup()

if __name__ == "__main__":
    if not config.DISCORD_TOKEN or config.DISCORD_TOKEN == '' or config.DISCORD_TOKEN == 'your_token_here':
        print("\n" + "="*60)
        print("❌ DISCORD_TOKEN KHÔNG HỢP LỆ!")
        print("="*60)
        print()
        print("🔍 Vấn đề: Token không được tìm thấy hoặc chưa cấu hình")
        print()
        print("📝 GIẢI PHÁP:")
        print()
        print("   Option 1: Fix token")
        print("   ─────────────────────────────────────")
        print("   1. Mở file .env")
        print("   2. Tìm dòng: DISCORD_TOKEN=...")
        print("   3. Đảm bảo token không bị trống")
        print("   4. Lưu file và chạy lại")
        print()
        print("   Option 2: Check token")
        print("   ─────────────────────────────────────")
        print("   Chạy: RUN_BOT.bat → Chọn [3] Check Token")
        print("   Để kiểm tra token có hoạt động không")
        print()
        print("   Option 3: Dùng Webhook Bot")
        print("   ─────────────────────────────────────")
        print("   Chạy: RUN_BOT.bat → Chọn [2] Webhook Bot")
        print("   Không cần token, chỉ cần webhook URL")
        print()
        print("="*60)
        input("\nNhấn Enter để thoát...")
        exit(1)
    
    print(f"\n🔐 Token: {config.DISCORD_TOKEN[:20]}...")
    print("🚀 Đang kết nối Discord...\n")
    
    try:
        bot.run(config.DISCORD_TOKEN)
    except discord.LoginFailure:
        print("\n" + "="*60)
        print("❌ KHÔNG THỂ ĐĂNG NHẬP!")
        print("="*60)
        print()
        print("🔍 Token không hợp lệ hoặc đã hết hạn")
        print()
        print("📝 CÁCH FIX:")
        print("   1. Vào: https://discord.com/developers/applications")
        print("   2. Chọn application của bạn")
        print("   3. Tab Bot → Click 'Reset Token'")
        print("   4. Copy token mới")
        print("   5. Paste vào file .env")
        print("   6. Chạy lại bot")
        print()
        print("="*60)
        input("\nNhấn Enter để thoát...")
        exit(1)
    except discord.PrivilegedIntentsRequired as e:
        print("\n" + "="*60)
        print("❌ PRIVILEGED INTENTS CHƯA ĐƯỢC BẬT!")
        print("="*60)
        print()
        print("🔍 Lỗi: Bot cần quyền đặc biệt (Intents) chưa được bật")
        print()
        print("📝 CÁCH FIX (5 PHÚT):")
        print()
        print("   1. Mở: https://discord.com/developers/applications")
        print("   2. Chọn application của bạn")
        print("   3. Vào tab 'Bot'")
        print("   4. Scroll xuống 'Privileged Gateway Intents'")
        print("   5. BẬT 3 INTENTS:")
        print()
        print("      ✅ Presence Intent")
        print("      ✅ Server Members Intent")
        print("      ✅ Message Content Intent")
        print()
        print("   6. Click 'Save Changes'")
        print("   7. Đợi 1-2 phút")
        print("   8. Chạy lại bot")
        print()
        print("📖 Đọc chi tiết: BAT_INTENTS.txt")
        print()
        print("="*60)
        input("\nNhấn Enter để thoát...")
        exit(1)
    except KeyboardInterrupt:
        print("\n⏹️ Bot stopped by user")
    except Exception as e:
        error_msg = str(e).lower()
        if "intent" in error_msg or "privilege" in error_msg:
            print("\n" + "="*60)
            print("❌ LỖI INTENTS!")
            print("="*60)
            print()
            print("🔍 Bot cần Privileged Intents chưa được bật")
            print()
            print("📝 FIX NGAY:")
            print("   → Mở file: BAT_INTENTS.txt")
            print("   → Làm theo hướng dẫn chi tiết")
            print("   → Hoặc vào: https://discord.com/developers/applications")
            print("   → Tab Bot → Bật 3 Intents → Save")
            print()
            print(f"Chi tiết lỗi: {e}")
            print()
            print("="*60)
        else:
            print(f"\n❌ Lỗi: {e}")
        input("\nNhấn Enter để thoát...")
        exit(1)
    finally:
        asyncio.run(cleanup())

