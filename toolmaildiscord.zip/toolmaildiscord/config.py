import os
from dotenv import load_dotenv

load_dotenv()

# Discord Configuration
DISCORD_TOKEN = os.getenv('DISCORD_TOKEN', '')
NOTIFICATION_CHANNEL_ID = int(os.getenv('NOTIFICATION_CHANNEL_ID', '0'))

# Webhook Configuration
WEBHOOK_URL = os.getenv('WEBHOOK_URL', '')

# Email Configuration
EMAIL_PREFIX = os.getenv('EMAIL_PREFIX', 'zer')
EMAIL_DOMAIN = os.getenv('EMAIL_DOMAIN', 'niceminute.com')
STARTING_NUMBER = int(os.getenv('STARTING_NUMBER', '0'))

# Generator.email URLs
GENERATOR_EMAIL_URL = 'https://generator.email'

