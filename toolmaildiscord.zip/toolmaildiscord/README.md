# 🤖 Discord Email Bot - Tự Động Tạo Email & Thông Báo OTP

Bot Discord tự động tạo email tạm thời từ generator.email và phát hiện OTP.

## ✨ Tính Năng

- 📧 **Tự động tạo email** từ generator.email
- 🔢 **Auto increment**: zer000 → zer001 → zer002...
- 🔐 **Phát hiện OTP tự động** và thông báo
- 💬 **2 chế độ**: Discord Bot (buttons) hoặc Webhook Bot
- 💾 **Lưu lịch sử** và counter tự động
- 🇻🇳 **Hỗ trợ tiếng Việt**

## 🚀 Cài Đặt & Chạy (1 Click!)

### Windows:
```bash
# Double-click file này:
RUN_BOT.bat
```

Script tự động:
- ✅ Cài Python 3.12 (nếu chưa có)
- ✅ Cài dependencies
- ✅ Setup config
- ✅ Chạy bot

### Linux/Mac:
```bash
# Cài dependencies
pip install -r requirements.txt

# Chạy Discord Bot
python bot.py

# Hoặc Webhook Bot
python webhook_bot.py
```

## ⚙️ Cấu Hình

File `.env` đã được tạo sẵn với:
- ✅ Discord Bot Token
- ✅ Webhook URL
- ✅ Email config (zer000@niceminute.com)

### Thay đổi cấu hình

Chỉnh sửa file `.env`:
```env
# Discord Bot Token
DISCORD_TOKEN=your_token_here

# Webhook URL (cho webhook bot)
WEBHOOK_URL=your_webhook_url

# Email config
EMAIL_PREFIX=zer              # Prefix email
EMAIL_DOMAIN=niceminute.com   # Domain
STARTING_NUMBER=0             # Số bắt đầu
```

## 🎮 Chọn Loại Bot

### Option 1: Discord Bot (Đầy đủ tính năng)

**Tính năng:**
- ✅ Slash commands (`/setup`, `/status`)
- ✅ Button tương tác
- ✅ DM notifications
- ✅ Multi-user support

**Cách dùng:**
1. Chạy `RUN_BOT.bat` → Chọn `[1]`
2. Trong Discord, gõ `/setup`
3. Click button "📧 Tạo Email Mới"
4. Nhận thông báo DM khi có OTP

**Setup Discord Bot:**

⚠️ **QUAN TRỌNG: Bật Intents trước khi chạy bot!**

1. Vào [Discord Developer Portal](https://discord.com/developers/applications)
2. Create Application → Bot tab → Copy Token
3. **Bật 3 Privileged Intents** (BẮT BUỘC):
   - ✅ **Presence Intent**
   - ✅ **Server Members Intent**
   - ✅ **Message Content Intent**
   - Click **"Save Changes"**
   
4. **Invite bot:** Copy link này và paste vào browser:
```
https://discord.com/api/oauth2/authorize?client_id=1431934517450506240&permissions=277025770496&scope=bot%20applications.commands
```
5. Cấu hình `NOTIFICATION_CHANNEL_ID` trong `.env`
6. Chạy bot → Bot tự động gửi menu!

### Option 2: Webhook Bot (Đơn giản - Khuyên dùng!)

**Tính năng:**
- ✅ Không cần bot token
- ✅ Chỉ cần webhook URL
- ✅ **Buttons chuyên nghiệp** với Discord Components
- ✅ **Nút Copy Email** và **Copy OTP**
- ✅ **Tự động xóa** messages sau 10 tin hoặc 1 giờ
- ✅ Menu tương tác trong Discord
- ✅ Console menu

**Cách dùng:**
1. Chạy `RUN_BOT.bat` → Chọn `[2]`
2. Menu console:
   - `[1]` Tạo email mới
   - `[2]` Xem status
   - `[3]` Dừng theo dõi
   - `[4]` Gửi menu Discord
   - `[5]` Thoát

3. **Trong Discord:**
   - Nhấn button **"📧 Tạo Email Mới"**
   - Nhấn **"Copy: email@domain.com"** để copy email
   - Khi có OTP: Nhấn **"Copy OTP: 123456"** để copy

**Lấy Webhook URL:**
1. Discord → Right-click channel → Edit Channel
2. Integrations → Webhooks → New Webhook
3. Copy URL

**Auto Cleanup:**
- Messages tự động xóa sau **10 tin** HOẶC **1 giờ**
- Giữ channel luôn gọn gàng
- Không cần xóa thủ công

## 📧 Format Email

```
{prefix}{number:03d}@{domain}
```

**Ví dụ:**
- zer000@niceminute.com
- zer001@niceminute.com
- zer002@niceminute.com

Số tự động tăng và lưu trong `email_data.json`

## 🔐 Phát Hiện OTP

Bot tự động tìm OTP theo patterns:
- `123456` (4-8 chữ số)
- `code: 123456`
- `OTP: 123456`
- `verification: 123456`
- `mã: 123456` (Vietnamese)

## 💬 Thông Báo

### Khi tạo email (Màu xanh):
```
✅ Email Đã Được Tạo!
📧 Email Address: zer000@niceminute.com
🌐 Truy cập trực tiếp: [Link]
📊 Email số: #000

Buttons:
[📋 Copy: zer000@niceminute.com] [🌐 Mở Generator.email]
[➕ Tạo Email Khác]
```

### Khi có OTP (Màu vàng):
```
@everyone 🔥 MÃ OTP MỚI! 🔥

🔑 PHÁT HIỆN OTP!
Email: zer000@niceminute.com

🔐 MÃ OTP
123456

📤 Từ: noreply@service.com
📋 Tiêu đề: Your verification code

Buttons:
[🔐 Copy OTP: 123456] [📧 Copy Email: zer000@niceminute.com]
```

### Auto Cleanup
- Messages tự động xóa sau **10 tin** hoặc **1 giờ**
- Giữ channel gọn gàng
- Không spam channel

## 🎯 Use Cases

### 1. Đăng ký tài khoản
```
→ Tạo email từ bot
→ Dùng email đăng ký Facebook/Google/etc
→ Nhận OTP tự động
→ Hoàn tất đăng ký
```

### 2. Testing/Development
```
→ Dev cần test email verification
→ Tạo nhiều emails nhanh
→ Theo dõi OTP realtime
→ Debug email flow
```

### 3. Email tạm thời
```
→ Không muốn dùng email thật
→ Tạo email disposable
→ Nhận thông báo qua Discord
→ Email tự xóa sau vài giờ
```

## 🛠️ Commands

### Discord Bot Slash Commands

| Command | Permission | Mô tả |
|---------|-----------|-------|
| `/setup` | Admin | Tạo button trong channel |
| `/status` | Everyone | Xem trạng thái bot |
| `/reset_counter` | Admin | Reset counter về 0 |

### Webhook Bot Console Menu

| Command | Mô tả |
|---------|-------|
| `[1]` | Tạo email mới và theo dõi |
| `[2]` | Xem status và emails đang theo dõi |
| `[3]` | Dừng theo dõi email cụ thể |
| `[4]` | Thoát bot |

## 📂 Cấu Trúc Files

```
toolmaildiscord/
├── RUN_BOT.bat          # All-in-one launcher ⭐
├── bot.py               # Discord bot (slash commands + buttons)
├── webhook_bot.py       # Webhook bot (simple)
├── email_manager.py     # Email logic & OTP detection
├── config.py            # Config loader
├── requirements.txt     # Dependencies
├── .env                 # Configuration (auto-generated)
├── email_data.json      # Data storage (auto-generated)
└── README.md            # This file
```

## 🐛 Troubleshooting

### Bot không online?
```
✅ Check DISCORD_TOKEN trong .env
✅ Check internet connection
✅ Xem console logs
```

### Không nhận thông báo?
```
✅ Bật DM trong server settings
✅ Check NOTIFICATION_CHANNEL_ID
✅ Bot có quyền Send Messages không?
```

### Email không được tạo?
```
✅ Check generator.email có hoạt động?
✅ Thử đổi domain khác (emailnax.com, vomoto.com)
✅ Xem console có lỗi gì
```

### "Missing Permissions"?
```
✅ Re-invite bot với đủ permissions
✅ Check bot role trong server
```

## 🌐 Domains Khả Dụng

Một số domain phổ biến trên generator.email:
- `niceminute.com` ⭐ (khuyên dùng)
- `emailnax.com`
- `vomoto.com`
- `robot-mail.com`
- `nongzaa.net`
- `gotmail.com`

## 💾 Data Storage

Bot tự động tạo file `email_data.json`:
```json
{
  "current_number": 5,
  "active_emails": {
    "zer000@niceminute.com": {
      "email": "zer000@niceminute.com",
      "created_at": "2025-10-26T10:30:00",
      "last_checked": "2025-10-26T10:35:00",
      "cookies": {},
      "messages": []
    }
  }
}
```

**Lưu ý:** KHÔNG xóa file này nếu muốn giữ counter!

## 🔒 Security

⚠️ **Quan trọng:**
- **KHÔNG** share Discord Bot Token
- **KHÔNG** share Webhook URL
- **KHÔNG** commit .env lên GitHub
- Chỉ dùng email tạm cho test/demo
- Email sẽ tự động xóa sau vài giờ

## 📊 Tech Stack

| Component | Technology |
|-----------|------------|
| Language | Python 3.12+ |
| Discord API | discord.py 2.3.2 |
| HTTP Client | aiohttp 3.9.1 |
| HTML Parser | beautifulsoup4 4.12.2 |
| Environment | python-dotenv 1.0.0 |

## 💡 Tips & Tricks

### Tip 1: Nhiều user cùng dùng
Mỗi user có thể tạo email riêng. Bot theo dõi nhiều emails cùng lúc!

### Tip 2: Check email trực tiếp
Truy cập: `https://generator.email/zer000@niceminute.com`

### Tip 3: Backup counter
Copy file `email_data.json` để backup.

### Tip 4: Custom prefix
Đổi `EMAIL_PREFIX` trong `.env` (ví dụ: test, bot, myname)

### Tip 5: Faster checking
Giảm `CHECK_INTERVAL` trong code để check nhanh hơn (mặc định 10s)

## 📈 Performance

- **Memory:** ~50-100 MB
- **CPU:** Low (idle most of time)
- **Network:** Moderate (API calls every 10s per email)
- **Max emails:** ~100 concurrent (recommended)

## 🎓 Example Flow

```
User → Click "Tạo Email" button
  ↓
Bot → Generate zer000@niceminute.com
  ↓
Bot → Start monitoring inbox (every 10s)
  ↓
User → Use email to register on Facebook
  ↓
Facebook → Send email with OTP: 123456
  ↓
Bot → Detect new email
  ↓
Bot → Extract OTP: 123456
  ↓
Bot → Send notification "🔑 OTP: 123456"
  ↓
User → Copy OTP and complete registration ✅
```

## 🚀 Quick Start Summary

```bash
# 1. Chạy bot
RUN_BOT.bat

# 2. Chọn loại bot (1 hoặc 2)

# 3. Nếu chọn Discord Bot:
#    - Gõ /setup trong Discord
#    - Click button "Tạo Email"

# 4. Nếu chọn Webhook Bot:
#    - Nhấn [1] để tạo email
#    - Bot tự động thông báo

# 5. Enjoy! 🎉
```

## 📞 Support

Nếu cần giúp đỡ:
1. Check console logs
2. Test webhook/bot token
3. Restart bot
4. Check file .env

## 📝 Changelog

### v1.0.0 (2025-10-26)
- ✅ Discord bot với slash commands
- ✅ Webhook bot alternative
- ✅ Auto OTP detection
- ✅ All-in-one installer
- ✅ Vietnamese support

## 📄 License

MIT License - Free to use and modify

---

**Made with ❤️ for Vietnamese Discord Community 🇻🇳**

**Bắt đầu ngay:** `RUN_BOT.bat` ⭐
