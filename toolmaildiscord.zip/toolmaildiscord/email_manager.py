import asyncio
import aiohttp
import json
import os
import re
import ssl
from datetime import datetime
from bs4 import BeautifulSoup
from typing import Optional, Dict, List

class EmailManager:
    def __init__(self, prefix: str, domain: str, starting_number: int = 0):
        self.prefix = prefix
        self.domain = domain
        self.current_number = starting_number
        self.data_file = 'email_data.json'
        self.session: Optional[aiohttp.ClientSession] = None
        self.active_emails: Dict[str, Dict] = {}
        self.load_data()
    
    def load_data(self):
        """Load email counter và active emails từ file"""
        if os.path.exists(self.data_file):
            try:
                with open(self.data_file, 'r') as f:
                    data = json.load(f)
                    self.current_number = data.get('current_number', self.current_number)
                    self.active_emails = data.get('active_emails', {})
            except Exception as e:
                print(f"Error loading data: {e}")
    
    def save_data(self):
        """Lưu email counter và active emails vào file"""
        data = {
            'current_number': self.current_number,
            'active_emails': self.active_emails
        }
        with open(self.data_file, 'w') as f:
            json.dump(data, f, indent=2)
    
    def generate_email_address(self) -> str:
        """Tạo email address mới với counter tăng dần"""
        email = f"{self.prefix}{self.current_number:03d}@{self.domain}"
        self.current_number += 1
        self.save_data()
        return email
    
    async def init_session(self):
        """Khởi tạo aiohttp session"""
        if self.session is None:
            # Tạo connector với SSL verification disabled (fix SSL error trên Windows)
            import ssl
            ssl_context = ssl.create_default_context()
            ssl_context.check_hostname = False
            ssl_context.verify_mode = ssl.CERT_NONE
            
            connector = aiohttp.TCPConnector(ssl=ssl_context)
            self.session = aiohttp.ClientSession(connector=connector)
    
    async def close_session(self):
        """Đóng aiohttp session"""
        if self.session:
            await self.session.close()
            self.session = None
    
    async def create_email_session(self, email: str) -> Dict:
        """Tạo session cho email trên generator.email với retry logic"""
        await self.init_session()
        
        max_retries = 3
        retry_delay = 2  # seconds
        
        for attempt in range(max_retries):
            try:
                # Truy cập generator.email với custom email
                url = f"https://generator.email/{email}"
                
                headers = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                    'Accept-Language': 'en-US,en;q=0.5',
                    'Accept-Encoding': 'gzip, deflate, br',
                    'Connection': 'keep-alive',
                    'Upgrade-Insecure-Requests': '1'
                }
                
                if attempt > 0:
                    print(f"🔄 Thử lại lần {attempt + 1}/{max_retries}...")
                
                async with self.session.get(url, headers=headers, ssl=False, timeout=aiohttp.ClientTimeout(total=30)) as response:
                    if response.status == 200:
                        html = await response.text()
                        soup = BeautifulSoup(html, 'html.parser')
                        
                        # Lưu thông tin email session
                        email_info = {
                            'email': email,
                            'created_at': datetime.now().isoformat(),
                            'last_checked': datetime.now().isoformat(),
                            'cookies': dict(response.cookies),
                            'messages': []
                        }
                        
                        self.active_emails[email] = email_info
                        self.save_data()
                        
                        if attempt > 0:
                            print(f"✅ Kết nối thành công sau {attempt + 1} lần thử!")
                        
                        return email_info
                    else:
                        if attempt < max_retries - 1:
                            await asyncio.sleep(retry_delay * (attempt + 1))
                            continue
                        return {'error': f'HTTP {response.status}: Generator.email từ chối kết nối'}
                        
            except aiohttp.ServerDisconnectedError as e:
                if attempt < max_retries - 1:
                    print(f"⚠️  Server disconnected (attempt {attempt + 1}/{max_retries}), đang retry...")
                    await asyncio.sleep(retry_delay * (attempt + 1))
                    
                    # Recreate session after disconnect
                    await self.close_session()
                    await self.init_session()
                    continue
                else:
                    return {'error': 'Server disconnected: Generator.email ngắt kết nối. Thử tạo email khác.'}
                    
            except aiohttp.ClientSSLError as e:
                if attempt < max_retries - 1:
                    await asyncio.sleep(retry_delay)
                    continue
                return {'error': 'SSL Error: Không thể kết nối an toàn. Chạy FIX_SSL.bat nếu lỗi lặp lại.'}
                
            except aiohttp.ClientConnectorError as e:
                if attempt < max_retries - 1:
                    await asyncio.sleep(retry_delay * 2)
                    continue
                return {'error': 'Connection Error: Không thể kết nối đến generator.email. Kiểm tra internet.'}
                
            except asyncio.TimeoutError:
                if attempt < max_retries - 1:
                    print(f"⏱️  Timeout (attempt {attempt + 1}/{max_retries}), đang retry...")
                    await asyncio.sleep(retry_delay)
                    continue
                return {'error': 'Timeout: Generator.email không phản hồi sau 30s. Thử lại sau.'}
                
            except Exception as e:
                error_msg = str(e)
                
                # Retry on generic errors too
                if attempt < max_retries - 1 and 'disconnect' in error_msg.lower():
                    print(f"⚠️  Connection error (attempt {attempt + 1}/{max_retries}): {error_msg[:60]}")
                    await asyncio.sleep(retry_delay * (attempt + 1))
                    
                    # Recreate session
                    await self.close_session()
                    await self.init_session()
                    continue
                
                if 'SSL' in error_msg or 'certificate' in error_msg.lower():
                    return {'error': 'SSL Certificate Error: Lỗi bảo mật kết nối. Chạy FIX_SSL.bat'}
                return {'error': f'Lỗi tạo email: {error_msg[:100]}'}
        
        # Should not reach here, but just in case
        return {'error': 'Không thể tạo email sau nhiều lần thử. Vui lòng thử lại sau.'}
    
    async def check_for_messages(self, email: str) -> List[Dict]:
        """Kiểm tra email có tin nhắn mới không"""
        await self.init_session()
        
        if email not in self.active_emails:
            return []
        
        try:
            url = f"https://generator.email/{email}"
            
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
            }
            
            # Thêm cookies nếu có
            cookies = self.active_emails[email].get('cookies', {})
            
            async with self.session.get(url, headers=headers, cookies=cookies, ssl=False, timeout=aiohttp.ClientTimeout(total=20)) as response:
                if response.status == 200:
                    html = await response.text()
                    soup = BeautifulSoup(html, 'html.parser')
                    
                    messages = []
                    
                    # Parse HTML để tìm messages
                    # Generator.email hiển thị inbox trong HTML
                    messages = []
                    
                    # Strategy 1: Tìm trong inbox list
                    email_items = soup.find_all(['div', 'tr', 'li', 'article'], 
                                               class_=lambda x: x and any(keyword in str(x).lower() 
                                                                         for keyword in ['email', 'message', 'mail', 'e7m', 'inbox-item']))
                    
                    for item in email_items[:10]:  # Giới hạn 10 emails mới nhất
                        try:
                            # Extract subject - try multiple selectors
                            subject = ""
                            
                            # Try to find subject in various ways
                            subject_selectors = [
                                # By class name
                                lambda: item.find(['span', 'div', 'td', 'a', 'h3', 'h4', 'strong', 'b'], 
                                                 class_=lambda x: x and 'subject' in str(x).lower()),
                                # By attribute
                                lambda: item.find(['a', 'span', 'div'], attrs={'class': re.compile(r'subject', re.I)}),
                                # By title attribute
                                lambda: item.find(['a', 'span', 'div'], attrs={'title': True}),
                                # First link in item
                                lambda: item.find('a'),
                                # First strong/bold text
                                lambda: item.find(['strong', 'b']),
                            ]
                            
                            for selector in subject_selectors:
                                try:
                                    elem = selector()
                                    if elem:
                                        text = elem.get_text(strip=True)
                                        # Subject thường dài hơn 3 ký tự và không phải chỉ là số
                                        if text and len(text) > 3:
                                            subject = text
                                            break
                                except:
                                    continue
                            
                            # Extract sender
                            sender = ""
                            for selector in [
                                lambda: item.find(['span', 'div', 'td'], class_=lambda x: x and 'from' in str(x).lower()),
                                lambda: item.find(['span', 'div'], attrs={'class': re.compile(r'sender|from', re.I)}),
                            ]:
                                elem = selector()
                                if elem:
                                    sender = elem.get_text(strip=True)
                                    if sender:
                                        break
                            
                            # Extract content/preview - try to get full text from item
                            content = item.get_text(separator=' ', strip=True)
                            
                            # Also try specific content areas
                            for selector in [
                                lambda: item.find(['span', 'div', 'td', 'p'], class_=lambda x: x and any(k in str(x).lower() for k in ['content', 'preview', 'body', 'text'])),
                            ]:
                                elem = selector()
                                if elem:
                                    text = elem.get_text(strip=True)
                                    if len(text) > len(content):
                                        content = text
                            
                            # Get message ID
                            msg_id = (item.get('data-message-id') or 
                                     item.get('id') or 
                                     item.get('data-id') or
                                     item.get('data-msg-id'))
                            
                            if not msg_id:
                                # Generate ID from content
                                msg_id = f"{hash(subject + sender + content[:100])}"
                            
                            if subject or content or sender:
                                # Clean content
                                content = content[:1000]  # Limit length
                                
                                messages.append({
                                    'id': str(msg_id),
                                    'subject': subject,
                                    'from': sender,
                                    'content': content,
                                    'body': content
                                })
                        except Exception as e:
                            # Skip malformed items
                            continue
                    
                    # Strategy 2: Nếu không tìm thấy messages, parse toàn bộ body
                    if not messages:
                        # Tìm tất cả text có chứa số (có thể là OTP)
                        all_text = soup.get_text(separator='\n', strip=True)
                        lines = all_text.split('\n')
                        
                        # Tìm lines có OTP keywords
                        otp_lines = []
                        for i, line in enumerate(lines):
                            if any(keyword in line.lower() for keyword in ['otp', 'code', 'verification', 'verify', 'mã', 'xác thực']):
                                # Lấy context (3 lines trước và sau)
                                context_start = max(0, i - 3)
                                context_end = min(len(lines), i + 4)
                                context = '\n'.join(lines[context_start:context_end])
                                otp_lines.append(context)
                        
                        if otp_lines:
                            # Tạo fake message từ OTP lines
                            messages.append({
                                'id': f"{hash(''.join(otp_lines))}",
                                'subject': 'Email Message',
                                'from': 'Unknown Sender',
                                'content': '\n\n'.join(otp_lines[:3]),  # Top 3 matches
                                'body': '\n\n'.join(otp_lines[:3])
                            })
                    
                    # Update last checked time
                    self.active_emails[email]['last_checked'] = datetime.now().isoformat()
                    self.save_data()
                    
                    return messages
                    
        except aiohttp.ServerDisconnectedError:
            # Server disconnect - silent fail, sẽ retry lần sau
            pass
        except aiohttp.ClientError as e:
            # Network errors - silent fail
            pass
        except asyncio.TimeoutError:
            # Timeout - silent fail
            pass
        except Exception as e:
            # Log unexpected errors nhưng không crash
            error_msg = str(e)
            if 'JSON' not in error_msg and 'mimetype' not in error_msg:
                print(f"⚠️  Error checking {email}: {str(e)[:100]}")
        
        return []
    
    def extract_otp_from_message(self, message_content: str) -> Optional[str]:
        """Tìm OTP code trong nội dung email"""
        # Patterns phổ biến cho OTP (4-8 chữ số)
        patterns = [
            # Vietnamese patterns (PRIORITY)
            r'(\d{4,8})[^\d]{0,30}(?:là mã|la ma|mã xác|ma xac)',  # "30181 là mã xác minh"
            r'(?:mã|ma)[^\d]{0,30}(\d{4,8})',  # "mã: 30181"
            
            # English patterns
            r'(\d{4,8})[^\d]{0,30}(?:is your|is the|verification|verify)',  # "30181 is your code"
            r'(?:OTP|otp|code|Code|CODE|verification|Verification)[:\s]*[^\d]*(\d{4,8})',  # "OTP: 12345"
            r'(?:is|là|your|của bạn)[:\s]*[^\d]*(\d{4,8})',  # "is 12345"
            
            # General digit patterns (LAST RESORT)
            r'\b(\d{5})\b',  # Exactly 5 digits
            r'\b(\d{6})\b',  # Exactly 6 digits  
            r'\b(\d{4})\b',  # Exactly 4 digits
            r'\b(\d{7})\b',  # Exactly 7 digits
            r'\b(\d{8})\b',  # Exactly 8 digits
        ]
        
        for pattern in patterns:
            match = re.search(pattern, message_content, re.IGNORECASE | re.UNICODE)
            if match:
                code = match.group(1)
                # Validate: OTP thường là 4-8 chữ số
                if 4 <= len(code) <= 8 and code.isdigit():
                    return code
        
        return None
    
    async def monitor_email(self, email: str, callback, check_interval: int = 10):
        """Monitor email liên tục và gọi callback khi có tin nhắn mới"""
        seen_messages = set()
        error_count = 0
        max_errors = 5
        check_count = 0
        
        print(f"👁️  Bắt đầu theo dõi: {email}")
        print(f"🔄 Refresh mỗi {check_interval} giây")
        
        while email in self.active_emails:
            try:
                check_count += 1
                
                # Show check progress every 6 checks (1 minute if interval=10s)
                if check_count % 6 == 1:
                    print(f"🔍 Checking {email}... (check #{check_count})")
                
                messages = await self.check_for_messages(email)
                
                # Reset error count on success
                if messages or error_count > 0:
                    error_count = 0
                
                for message in messages:
                    message_id = message.get('id', '')
                    if message_id and message_id not in seen_messages:
                        seen_messages.add(message_id)
                        
                        # Extract thông tin quan trọng
                        subject = message.get('subject', '')
                        content = message.get('content', '') or message.get('body', '')
                        sender = message.get('from', '')
                        
                        # Tìm OTP trong subject + content
                        full_text = f"{subject} {content}"
                        otp = self.extract_otp_from_message(full_text)
                        
                        # Debug: Show what we found
                        print(f"📨 Email mới cho {email}")
                        print(f"   Subject: {subject[:80]}")
                        print(f"   From: {sender[:50]}")
                        print(f"   Content preview: {content[:100]}")
                        
                        if otp:
                            print(f"   🔐 OTP DETECTED: {otp}")
                        else:
                            # Debug: show numbers found
                            numbers = re.findall(r'\d{4,8}', full_text)
                            if numbers:
                                print(f"   🔍 Numbers found (not matched as OTP): {numbers}")
                            else:
                                print(f"   ⚠️  No numbers found in message")
                        
                        # Gọi callback ngay cả khi không có OTP
                        await callback({
                            'email': email,
                            'subject': subject,
                            'content': content,
                            'sender': sender,
                            'otp': otp,
                            'message_id': message_id
                        })
                
                await asyncio.sleep(check_interval)
                
            except asyncio.CancelledError:
                # Task bị cancel - exit gracefully
                print(f"⏹️  Dừng theo dõi: {email}")
                break
            except Exception as e:
                error_count += 1
                error_msg = str(e)
                
                # Only log significant errors
                if error_count <= 3 and 'disconnect' not in error_msg.lower():
                    print(f"⚠️  Error monitoring {email} (attempt {error_count}): {error_msg[:80]}")
                
                if error_count >= max_errors:
                    print(f"❌ Too many errors for {email}, pausing monitoring...")
                    await asyncio.sleep(60)  # Wait 1 minute before retry
                    error_count = 0
                else:
                    await asyncio.sleep(check_interval)
    
    def stop_monitoring(self, email: str):
        """Dừng monitoring một email"""
        if email in self.active_emails:
            del self.active_emails[email]
            self.save_data()

